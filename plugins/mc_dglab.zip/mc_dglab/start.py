import json
import time

import dockdglab
import create_ui
import mc_dglab
# 插件名和插件作者 插件名为必须项
plugin_name = "mc_dglab"


class App:
    author = "YingXIAmour"
    html = ""
    ui = None
    config = None
    waveform = None
    flask_app = None
    server = None

app = App()
mc = None

def init():
    """
    初始化
    data参数有：websockets(惩罚姬的websocket通信服务) coyotes(惩罚姬的蓝牙通信服务) config(插件配置) log(日志) ui(插件配置页面构建所用) http(插件配置页面所需的功能配置)
    :param data:由惩罚姬导入时传过来的参数
    :return:
    """
    global app,mc
    # 捕获所有初始化异常，打印精准报错位置
    try:
        app.server = dockdglab.DockDGLab()
        app.config = app.server.get_config(plugin_name) or {}  # 容错：空配置
        app.waveform = app.config.get("waveform", {})
        app.ui = create_ui.PluginUI(plugin_name=f"{plugin_name}")
        mc = mc_dglab.McUdpReceiver(app=app)
        # 执行UI初始化
        u = ui_init()

        # 统一打印结果
        if u == "success":
            app.server.log("success", f"{plugin_name} 插件初始化完成")
        else:
            app.server.log("warning", f"UI初始化:{u}")

    except Exception as e:
        import traceback
        error_detail = traceback.format_exc()
        print(f"\n==================== {plugin_name} 初始化崩溃 ====================")
        print(f"错误信息：{str(e)}")
        print(f"详细堆栈：\n{error_detail}")
        print("==============================================================\n")
        try:
            if app.server:
                app.server.log("error", f"初始化失败：{str(e)}")
        except:
            pass

def save(data):
    return json.dumps({"message": "测试函数"})


def ui_init():
    """配置页面初始化"""
    global app
    try:
        # 🔥 修复1：所有配置读取加默认值，防止KeyError崩溃
        cf = app.config.get("plugins", {})
        one_health_strength = cf.get("one_health_strength", {})
        die_strength = cf.get("die_strength", {})
        min_strength = cf.get("min_strength", {})
        down_wait = cf.get("down_wait",{})
        die_down_wait = cf.get("die_down_wait",{})
        # 常规配置
        app.ui.add_title("每点血量受到的伤害")
        app.ui.add_input("one_health_strength_A", "A通道", one_health_strength.get("A", 0))
        app.ui.add_input("one_health_strength_B", "B通道", one_health_strength.get("B", 0))

        app.ui.add_title("死亡时强度")
        app.ui.add_input("die_strength_A", "A通道", die_strength.get("A", 100))
        app.ui.add_input("die_strength_B", "B通道", die_strength.get("B", 100))

        app.ui.add_title("最小强度（受伤后缓降）")
        app.ui.add_input("min_strength_A", "A通道", min_strength.get("A", 10))
        app.ui.add_input("min_strength_B", "B通道", min_strength.get("B", 10))

        app.ui.add_title("缓降等待时间（毫秒）")
        app.ui.add_input("down_wait_A", "A通道", down_wait.get("A", 2500))
        app.ui.add_input("down_wait_B", "B通道", down_wait.get("B", 2500))

        app.ui.add_title("死亡缓降等待时间（毫秒）")
        app.ui.add_input("die_down_wait_A", "A通道", die_down_wait.get("A", 2500))
        app.ui.add_input("die_down_wait_B", "B通道", die_down_wait.get("B", 2500))

        app.ui.add_text("注：缓降没做好，直接用的设置强度值（原本是想仿制原Fabric端的DgLab x Minecraft的） 等待时间只有A可以使用，B设置无效 （A其实就是全局AB了，以后能做缓降了再试试）")
        # 波形配置
        app.ui.add_waveform(app.waveform)
        # 底部按钮
        app.ui.add_global_btn("保存", "save")
        app.html = app.ui.build()

        return "success"
    except Exception as e:
        app.server.log("error",f"ui_init错误: {e}")
        import traceback
        traceback.print_exc()
        return str(e)


def start():
    """插件启动"""
    mc.start()
    while mc.running:
        continue
def stop():
    try:
        mc.stop()
        app.server.log("info", "mc_dglab已关闭")
    except Exception as e:
        import traceback
        app.server.log("error", f"mc_dglab关闭异常：{e}\n{traceback.format_exc()}")