import socket
import threading
import time
import json


class McUdpReceiver:
    def __init__(self, ip: str = "127.0.0.1", port: int = 9988, app=None):
        # 通信配置
        self.udp_ip = ip
        self.udp_port = port
        self.sock = None
        self.app = app
        self.config = self.app.config.get("plugins")
        self.waveform = self.app.waveform
        # 运行控制信号（退出开关）
        self.running = False
        self.force_shutdown = False  # 新增强制关闭标记
        self.mc_connected = False

        # 玩家数据存储
        self.player_name = ""
        self.player_health = 20.0
        self.player_max_health = 20.0
        self.damage = 0.0
        # 新增：死亡状态标记
        self.is_dead = False
        self.last_is_dead = False
        # 新增：是否是第一次接收数据包标记
        self.first_recv = True

        self.strength = {'A': [0, 100], 'B': [0, 100]}
        self.w = self.waveform.get("Normal")

        # 血量稳定检测专用变量
        self.last_check_hp = self.player_health
        self.hp_stable_timer = 0.0
        self.hp_stable_threshold = 0.001
        # 稳定等待毫秒（复用原有down_wait，取A通道时长作为统一稳定等待时间）
        self.stable_wait_ms = self.config.get("down_wait").get("A", 2500)
        self.need_run_gradient = False  # 是否需要执行缓降

        # 线程对象
        self.udp_thread = None
        self.timer_thread = None
        self.stable_check_thread = None  # 新增：血量稳定检测线程
        self.delay_threads = []
        # ===== 缓降任务控制变量 =====
        # 任务锁
        self.task_lock = threading.Lock()
        # 通道中断信号 A/B
        self.chan_stop_event = {
            "A": threading.Event(),
            "B": threading.Event()
        }

    def delay_gradient_task(self, channel: str, wait_ms: int, base_hp: float):
        stop_evt = self.chan_stop_event[channel]
        try:
            total_wait = wait_ms / 100
            slice_t = 0.1
            stable_counter = 0.0

            while True:
                # 新伤害触发/程序关闭，直接退出，不缓降
                if stop_evt.is_set() or not self.running:
                    self.app.server.log("info", f"{channel} 血量发生变化，取消等待缓降")
                    return

                # 对比实时全局血量和上一次稳定血量
                if abs(self.player_health - base_hp) < self.hp_stable_threshold:
                    stable_counter += slice_t
                    # 稳定时长达标，退出循环执行缓降
                    if stable_counter >= total_wait:
                        break
                else:
                    # 血量发生波动（回血/微量变化），重置稳定计时，刷新基准对比值
                    base_hp = self.player_health
                    stable_counter = 0.0

                time.sleep(slice_t)

            # 稳定等待完成，执行缓降逻辑
            with self.task_lock:
                ratio = self.player_health / self.player_max_health
                sc = round(ratio, 2)
                if channel == "A":
                    s_max = self.strength['A'][1]
                    s_min = self.config.get("min_strength").get("A", 20)
                else:
                    s_max = self.strength['B'][1]
                    s_min = self.config.get("min_strength").get("B", 20)
                s = s_max * (1 - sc)

                target_strength = s if s < s_min else s_min

                self.app.server.log("info", f"{channel} 血量稳定无波动，执行缓降至{target_strength}")
                self.app.server.strength_gradient_over_time(strength=target_strength, channel=channel,
                                                            g_type="DECREASE", time=5)
        except Exception as e:
            self.app.server.log("error", f"{channel} 延时任务异常:{e}")
        finally:
            stop_evt.clear()

    def _stable_hp_check_loop(self):
        """新增独立线程：持续检测血量稳定，仅稳定后触发缓降"""
        slice_t = 0.1
        while self.running:
            time.sleep(slice_t)
            # 死亡状态直接跳过稳定检测
            if self.is_dead:
                self.stable_wait_ms = self.config.get("die_down_wait").get("A", 2500)
            #    self.hp_stable_timer = 0.0
            #    self.last_check_hp = self.player_health
            #    continue

            # 血量发生变动，重置稳定计时器
            if abs(self.player_health - self.last_check_hp) > self.hp_stable_threshold:
                self.hp_stable_timer = 0.0
                self.last_check_hp = self.player_health
                # 中断正在执行的旧缓降任务
                self.chan_stop_event["A"].set()
                self.chan_stop_event["B"].set()
                continue

            # 血量无波动，累计稳定时长
            self.hp_stable_timer += slice_t
            total_wait_sec = self.stable_wait_ms / 1000

            # 稳定时长达标，启动双通道缓降
            if self.hp_stable_timer >= total_wait_sec and not self.need_run_gradient:
                self.need_run_gradient = True
                #self.app.server.log("info", f"血量持续稳定{total_wait_sec}s,双通道设置最小强度")

                ratio = self.player_health / self.player_max_health
                sc = round(ratio, 2)
                s_max_a = self.strength['A'][1]
                s_min_a = self.config.get("min_strength").get("A", 20)
                s_max_b = self.strength['B'][1]
                s_min_b = self.config.get("min_strength").get("B", 20)
                sa = s_max_a * (1 - sc)
                sb = s_max_b * (1 - sc)
                target_strength_a = sa if sa < s_min_a else s_min_a
                target_strength_b = sb if sb < s_min_b else s_min_b

                self.app.server.set_strength(strength=round(target_strength_a), channel="A")
                self.app.server.set_strength(strength=round(target_strength_b), channel="B")
                #self.need_run_gradient = False

                #with self.task_lock:
                    # 清理失效线程
                    #alive_threads = []
                    #for t in self.delay_threads:
                    #   if t.is_alive():
                    #       alive_threads.append(t)
                    #self.delay_threads = alive_threads

                    # 重置中断信号
                    #self.chan_stop_event["A"].clear()
                    #self.chan_stop_event["B"].clear()

                    #current_hp = self.player_health
                    #wait_a = self.config.get("down_wait").get("A", 2500)
                    #wait_b = self.config.get("down_wait").get("B", 2500)

                    #t_a = threading.Thread(
                    #    target=self.delay_gradient_task,
                    #    args=("A", wait_a, current_hp),
                    #    daemon=True
                    #)
                    #t_b = threading.Thread(
                    #    target=self.delay_gradient_task,
                    #    args=("B", wait_b, current_hp),
                    #    daemon=True
                    #)
                    #self.delay_threads.append(t_a)
                    #self.delay_threads.append(t_b)
                    #t_a.start()
                    #t_b.start()
                # 重置标记，避免重复创建线程
                self.need_run_gradient = False

    def start(self):
        """启动服务：初始化套接字、开启线程"""
        if self.running:
            self.app.server.log("warning", "服务已在运行，无需重复启动")
            return

        self.running = True
        # 创建UDP套接字并绑定端口
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((self.udp_ip, self.udp_port))
        self.sock.settimeout(1.0)  # 设置超时，避免阻塞无法退出
        self.app.server.log("info", f"UDP 监听已启动：{self.udp_ip}:{self.udp_port}")

        # 启动计时线程
        self.timer_thread = threading.Thread(target=self._timer_loop, daemon=True)
        self.timer_thread.start()
        self.app.server.log("info", "计时线程已启动")

        # 新增：启动血量稳定检测线程
        self.stable_check_thread = threading.Thread(target=self._stable_hp_check_loop, daemon=True)
        self.stable_check_thread.start()
        self.app.server.log("info", "血量稳定检测线程已启动")

        # 启动UDP接收线程
        self.udp_thread = threading.Thread(target=self._udp_receive_loop, daemon=True)
        self.udp_thread.start()
        self.app.server.log("info", "UDP接收线程已启动")

    def stop(self):
        """强制关闭所有线程与Socket"""
        if not self.running and self.force_shutdown:
            self.app.server.log("warning", "服务已经停止，无需重复操作")
            return

        # 1. 全局总开关置False，所有任务循环都会快速退出
        self.running = False
        self.force_shutdown = True

        # 2. 用Event统一终止A/B延时缓降任务
        lock_ok = self.task_lock.acquire(blocking=False)
        if lock_ok:
            try:
                self.chan_stop_event["A"].set()
                self.chan_stop_event["B"].set()
                self.app.server.log("success", "成功获取task_lock，触发所有延时任务终止信号")
            finally:
                self.task_lock.release()
        else:
            self.chan_stop_event["A"].set()
            self.chan_stop_event["B"].set()
            self.app.server.log("warning", "task_lock被业务线程占用，直接下发任务终止信号")

        # 3. 关闭UDP套接字，唤醒阻塞recvfrom
        if self.sock:
            try:
                self.sock.settimeout(0.0)
                self.sock.close()
            except Exception:
                pass
            self.sock = None
        self.app.server.log("info", "正在强制终止所有线程...")

        # 4. 等待各类主线程退出，超时直接放弃
        if self.udp_thread and self.udp_thread.is_alive():
            self.udp_thread.join(timeout=1.0)
        if self.timer_thread and self.timer_thread.is_alive():
            self.timer_thread.join(timeout=1.0)
        if self.stable_check_thread and self.stable_check_thread.is_alive():
            self.stable_check_thread.join(timeout=1.0)

        # 5. 等待全部缓降子线程退出，单线程最长等待0.5s
        for t in self.delay_threads:
            if t.is_alive():
                t.join(timeout=0.5)
        self.delay_threads.clear()

        self.app.server.log("info", "UDP服务强制退出完成")

    def _udp_receive_loop(self):
        """UDP接收循环（删除受伤立刻创建缓降线程逻辑）"""
        while self.running:
            try:
                data, addr = self.sock.recvfrom(1024)
                json_str = data.decode("utf-8").strip()
                data_dict = json.loads(json_str)
                pkg_hp = data_dict.get("health", 20.0)
                pkg_dmg = data_dict.get("Damage", 0.0)
                pkg_is_dead = data_dict.get("isDead", False)

                # 更新玩家基础数据
                self.player_name = data_dict.get("name", "")
                self.player_health = pkg_hp
                self.player_max_health = data_dict.get("maxHealth", 20.0)
                self.last_is_dead = self.is_dead
                self.is_dead = pkg_is_dead

                # ========== 需求1：死亡复活时全通道强度置0 ==========
                if self.last_is_dead is True and self.is_dead is False:
                    self.w = self.waveform.get("Normal")
                    self.app.server.set_strength(strength=0, channel="All")
                    self.app.server.log("info", "检测到复活，重置所有通道强度为0")

                # ========== 需求2：仅第一次接收数据包，用满血差值计算damage ==========
                if self.first_recv:
                    self.first_recv = False
                    diff_damage = self.player_max_health - self.player_health
                    if diff_damage > 0:
                        self.damage = diff_damage
                        self.app.server.log("info", f"首次接收数据，血量不满，模拟伤害值: {diff_damage}")
                    else:
                        self.damage = pkg_dmg
                else:
                    # 非首次，使用包内原始伤害
                    self.damage = pkg_dmg

                # 首次通信提示
                if not self.mc_connected:
                    self.mc_connected = True
                    self.app.server.log("success", "已与MC客户端建立通信")

                # 伤害触发逻辑：仅输出震动强度，不再启动缓降线程
                if self.damage > 0:
                    self.app.server.log("info", f"检测到伤害，数值：{self.damage}")
                    if self.player_health > 0:
                        a = round(self.damage * self.config.get("one_health_strength").get("A"))
                        b = round(self.damage * self.config.get("one_health_strength").get("B"))
                        self.app.server.add_strength(strength=a, channel="A")
                        self.app.server.add_strength(strength=b, channel="B")
                    elif self.player_health == 0:
                        a = self.config.get("die_strength").get("A")
                        b = self.config.get("die_strength").get("B")
                        self.w = self.waveform.get("Die")
                        self.app.server.set_strength(strength=a, channel="A")
                        self.app.server.set_strength(strength=b, channel="B")
                        self.app.server.send_waveform(waveform=self.w, channel="All", total_duration=10)

            except socket.timeout:
                continue
            except Exception as e:
                self.app.server.log("error", f"接收数据异常：{e}")

    def _timer_loop(self):
        """计时循环"""
        while self.running:
            self.strength = self.app.server.get_strength().get("msg")
            self.app.server.send_waveform(waveform=self.w, channel="All")
            time.sleep(1.0)

    def get_player_data(self) -> dict:
        """对外接口：获取当前存储的玩家数据"""
        return {
            "name": self.player_name,
            "health": self.player_health,
            "maxHealth": self.player_max_health,
            "Damage": self.damage,
            "isDead": self.is_dead
        }